import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Router,Routes } from 'react-router-dom';
import Author  from './pages/authors';
import Book from './pages/book';
import Catagory  from './pages/catagory';
import Navbar from './pages/navbar';



function App() {
  return (
    <div>
      <Navbar>
      <BrowserRouter>
      <Routes>
    <Route path="/authors" element={<Author/>} />
      <Route path="/book" element={<Book/>} component/>
      <Route path="/catagory" element={<Catagory/>} component/>
    </Routes>
      </BrowserRouter>

       
      </Navbar>

    </div>
  );
}

export default App;
